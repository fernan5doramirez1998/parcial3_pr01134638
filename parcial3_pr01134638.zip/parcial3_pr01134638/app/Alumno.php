<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Alumno extends Model
{
    protected $table = "alumnos";
    protected $primaryKey = 'idalumno';
    protected $fillable = ['nombre', 'apellido', 'fechanacimiento','direccion', 'genero', 'telefono', 'correo', 'clave',];
    
}