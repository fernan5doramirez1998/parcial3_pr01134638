<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Curso extends Model
{
    protected $table = "cursos";
    protected $primaryKey = 'idcurso';
    protected $fillable = ['nombrecurso', 'anio', 'ciclo', 'idprofesor',];

    public function profesor()
    {
        return $this->belongsTo(Profesor::class, 'idprofesor');
    }
}
