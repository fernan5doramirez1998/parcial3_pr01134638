<?php

namespace App\Http\Controllers;

use App\User;
//use App\Role;
use Illuminate\Http\Request;

class UserController extends Controller
{
    function __construct()
    {
        $this->middleware(['auth', 'roles:admin,estudiante,profesor']);
        //$this->middleware('role:admin', ['except' => ['edit']]);
          
    }
     
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users =  \App\User::all();
        return view('users.index', compact('users'));
    }

    /** 
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('users.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $info = $request->validate([
            'name' => 'required',
            'email' => 'required',
            'role' => 'required',
            'password' => 'required',
            
        ],[
            'name.required' => "El campo nombre es obligatorio",
            'email.required' => "El campo apellido es obligatorio",
            'role.required' => "El campo DUI es obligatorio",
            'password.required' => "El campo teléfono es obligatorio",
            
        ]);

        User::create($info);
        return redirect()->route('users.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user = User::findOrFail($id);
        return view('users.editar', compact('user'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $info = $request->validate([
            'name' => 'required',
            'email' => 'required',
            'role' => 'required',
            'password' => 'required',
            
        ],[
            'name.required' => "El campo nombre es obligatorio",
            'email.required' => "El campo email es obligatorio",
            'role.required' => "El campo Role es obligatorio",
            'password.required' => "El campo password es obligatorio",
            
        ]);

        User::findOrFail($id)->update($info);
        return redirect()->route('users.index');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        User::find($id)->delete();
        return redirect()->route('users.index');
    }

}
