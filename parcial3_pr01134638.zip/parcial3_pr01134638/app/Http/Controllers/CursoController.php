<?php

namespace App\Http\Controllers;

use App\Curso;
use App\Profesor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CursoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $cursos = Curso::all();
        return view('curso.index', compact('cursos'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categoria = Profesor::all();
            return view('curso.create', compact('categoria'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $info = $request->validate([
            'nombrecurso' => 'required',
            'anio' => 'required',
            'ciclo' => 'required',
            'idprofesor' => 'required',
        ],[
            'nombrecurso.required' => "El campo curso es obligatorio",
            'anio.required' => "El campo año es obligatorio",
            'ciclo.required' => "El campo ciclo es obligatorio",
            'idprofesor.required' => "El campo profesor es obligatorio",
        ]);

        Curso::create($info);
        return redirect()->route('curso.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Curso  $curso
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $curso = Curso::findOrFail($id);
        return view('curso.show', compact('curso'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Curso  $curso
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $curso = Curso::findOrFail($id);
        $categoria = Profesor::all();
        return view('curso.editar', compact('curso', 'categoria'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Curso  $curso
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $info = $request->validate([
            'nombrecurso' => 'required',
            'anio' => 'required',
            'ciclo' => 'required',
            'idprofesor' => 'required',
        ],[
            'nombrecurso.required' => "El campo curso es obligatorio",
            'anio.required' => "El campo año es obligatorio",
            'ciclo.required' => "El campo ciclo es obligatorio",
            'idprofesor.required' => "El campo profesor es obligatorio",
        ]);

        Curso::findOrFail($id)->update($info);
        return redirect()->route('curso.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Curso  $curso
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Curso::find($id)->delete();
        return redirect()->route('curso.index');
    }
}
