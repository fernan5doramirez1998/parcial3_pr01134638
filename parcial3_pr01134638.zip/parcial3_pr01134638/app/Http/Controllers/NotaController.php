<?php

namespace App\Http\Controllers;

use App\Nota;
use App\Alumno;
use App\Curso;
use App\Profesor;
use Illuminate\Http\Request;

class NotaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categoria = Alumno::all();
        $categoria1 = Profesor::all();
        $categoria2 = Curso::all();
        return view('nota.create', compact('categoria', 'categoria1', 'categoria2'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $info = $request->validate([
            'nota1' => 'required',
            'nota2' => 'required',
            'nota3' => 'required',
            'nota4' => 'required',
            'parcial' => 'required',
            'promedio' => 'required',
            'idalumno' => 'required',
            'idprofesor' => 'required',
            'idcurso' => 'required',
            
        ],[
            'nota1.required' => "El campo Nota 1 es obligatorio",
            'nota2.required' => "El campo Nota 2 es obligatorio",
            'nota3.required' => "El campo Nota 3 es obligatorio",
            'nota4.required' => "El campo Nota 4 es obligatorio",
            'parcial.required' => "El campo Parcial es obligatorio",
            'promedio.required' => "El campo Promedio es obligatorio",
            'idalumno.required' => "El campo Alumno es obligatorio",
            'idprofesor.required' => "El campo Profesor es obligatorio",
            'idcurso.required' => "El campo Curso es obligatorio",
        ]);

        Nota::create($info);
        return redirect()->route('nota.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Nota  $nota
     * @return \Illuminate\Http\Response
     */
    public function show(Nota $id)
    {
        $nota = Nota::findOrFail($id);
        return view('nota.show', compact('nota'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Nota  $nota
     * @return \Illuminate\Http\Response
     */
    public function edit(Nota $nota)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Nota  $nota
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Nota $nota)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Nota  $nota
     * @return \Illuminate\Http\Response
     */
    public function destroy(Nota $nota)
    {
        //
    }
}
