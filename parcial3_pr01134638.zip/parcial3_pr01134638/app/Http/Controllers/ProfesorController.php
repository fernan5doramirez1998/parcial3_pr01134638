<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Profesor;

class ProfesorController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
            
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $profesors = Profesor::all();
        return view('profesor.index', compact('profesors'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('profesor.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $info = $request->validate([
            'nombre' => 'required',
            'apellido' => 'required',
            'dui' => 'required',
            'telefono' => 'required',
            'email' => 'required',
            'clave' => 'required',
        ],[
            'nombre.required' => "El campo nombre es obligatorio",
            'apellido.required' => "El campo apellido es obligatorio",
            'dui.required' => "El campo DUI es obligatorio",
            'telefono.required' => "El campo teléfono es obligatorio",
            'email.required' => "El campo Email es obligatorio",
            'clave.required' => "El campo clave es obligatorio",
        ]);

        Profesor::create($info);
        return redirect()->route('profesor.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $profesor = Profesor::findOrFail($id);
        return view('profesor.show', compact('profesor'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $profesor = Profesor::findOrFail($id);
        return view('profesor.editar', compact('profesor'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $info = $request->validate([
            'nombre' => 'required',
            'apellido' => 'required',
            'dui' => 'required',
            'telefono' => 'required',
            'email' => 'required',
            'clave' => 'required',

        ],[
            'nombre.required' => "El campo nombre es obligatorio",
            'apellido.required' => "El campo apellido es obligatorio",
            'dui.required' => "El campo DUI es obligatorio",
            'telefono.required' => "El campo teléfono es obligatorio",
            'email.required' => "El campo Email es obligatorio",
            'clave.required' => "El campo clave es obligatorio",
        ]);
        Profesor::findOrFail($id)->update($info);
        return redirect()->route('profesor.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Profesor::find($id)->delete();
        return redirect()->route('profesor.index');
    }
}
