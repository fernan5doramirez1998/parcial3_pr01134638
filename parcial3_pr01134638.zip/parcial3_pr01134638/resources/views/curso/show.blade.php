@extends('layout')
@section('content')



<h2>Cursos</h2>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th>ID</th>
            <th>CURSO</th>
            <th>AÑO</th>
            <th>CICLO</th>
            <th>PROFESOR</th>
            
        </tr>
    </thead>
    <tbody>
        <th>
            {{$curso->idcurso }}
        </th>
        <th>
            {{$curso->nombrecurso }}
        </th>
        <th>
            {{$curso->anio }}
        </th>
        <th>
            {{$curso->ciclo }}
        </th>
        <th>
            {{$curso->profesor->nombre }}
        </th>
        
    </tbody>
       
</table>
<div class="d-flex justify-content-between">
    <p>
       <a class="btn btn-primary" href="{{ route('curso.index') }}">Regresar al listado de Cursos.</a>
   </p>
</div>
@endsection




