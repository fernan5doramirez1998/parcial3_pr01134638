
@extends('layout')
@section('title')
@section('content')

<div class="d-flex justify-content-between">
    <h1>Cursos</h1>
<p>
    <a class="btn btn-primary" href="{{ route('curso.create') }}">Nuevo Curso</a>
</p>
</div>

<table class="table">
    <thead class="thead-dark">
        
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Curso</th>
            <th scope="col">Acciones</th>
        </tr>
    </thead>
    <tbody>
    @foreach ($cursos as $curso)
        <tr>
        <td>
            {{ $curso->idcurso }}
        </td>
        {{-- <td>
            {{ $curso->nombrecurso }}
        </td>         --}}
             
        <td><a href="{{route('curso.show', $curso->idcurso)}}"> {{$curso->nombrecurso }}
        </td></a>
              
        <td><a href="{{ route('curso.edit', $curso->idcurso) }}"><span class="oi oi-pencil"></span></a>
            <form style="display: inline;" action="{{ route('curso.destroy', $curso->idcurso) }}" method="POST">
            {!! method_field('DELETE') !!}
            {!! csrf_field() !!}
            <button class="btn btn-link" type="submit"><span class="oi oi-trash"></span></button>
        </form>
        </td>         
        </tr>
    @endforeach
    </tbody>

</table>
@endsection

