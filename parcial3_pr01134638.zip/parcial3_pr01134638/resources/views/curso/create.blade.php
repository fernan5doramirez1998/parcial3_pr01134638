@extends('layout')
@section('title', "Crear Profesión")
@section('content')
    <h1>Crear Curso</h1>

    @if ($errors->any())
    <div class="alert alert-danger">
      <h6>Por favor complete los campos requeridos:</h6>
      <ul>
        @foreach ($errors->all() as $error)
          <li>{{ $error }}</li>
        @endforeach
      </ul>
    </div>
    @endif

    <form method="POST" action="{{ route('curso.store') }}">
       
        {!! csrf_field() !!}

        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Ingrese Curso: </label>
            <input type="text" name="nombrecurso" class="form-control" id="nombrecurso" rows="3" placeholder="Ejemplo: Programación III"
            value="{{ old('nombrecurso') }}">
            <br>

        </div>
        <div class="mb-3">
            <label for="exampleFormControlTextarea1" class="form-label">Ingrese Año</label>
            <input type="text" name="anio" class="form-control" id="anio" rows="3" placeholder="Año: 2021"
               value="{{ old('anio') }}">
            @if ($errors->has('anio'))
              <p>{{ $errors->first('anio') }}</p>
            @endif
        </div>     
            
        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Ingrese Ciclo</label>
          <input type="text" name="ciclo" class="form-control" id="ciclo" rows="3" placeholder="Ciclo: II"
             value="{{ old('ciclo') }}">
          @if ($errors->has('ciclo'))
            <p>{{ $errors->first('ciclo') }}</p>
          @endif
        </div>
        
        <div class="mb-3">
          <label class="form-label">Código Profesor: </label>
          <select class="form-select" name="idprofesor">
            <option value="">-Seleccione Profesor</option>
            @foreach ($categoria as $categorias)
              <option value="{{ $categorias['idprofesor'] }}">{{ $categorias['nombre'] }}</option>
                
            @endforeach
          </select>
        </div>
       
        <button type="submit" class="btn btn-primary">Crear Curso</button>
    </form>
    
@endsection