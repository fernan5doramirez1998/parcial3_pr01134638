@extends('layout')
@section('title', 'Editar Curso')
@section('content')
    <br>
    <h1>Editar Curso</h1>

    @if ($errors->any())
    <div class="alert alert-danger">
      <h6>Por favor complete los campos requeridos:</h6>
      <ul>
        @foreach ($errors->all() as $error)
          <li>{{ $error }}</li>
        @endforeach
      </ul>
    </div>
    @endif

    <form method="POST" action="{{ route('curso.update', $curso->idcurso) }}">
      {!! method_field('PUT') !!}
      {!! csrf_field() !!}

        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Curso: </label>
            <input type="text" name="nombrecurso" class="form-control" id="nombrecurso" rows="3" 
            value="{{ old('nombrecurso', $curso->nombrecurso) }}">
            
            @if ($errors->has('nombrecurso'))
              <p>{{ $errors->first('nombrecurso') }}</p>
            @endif
        </div>

        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Año: </label>
          <input type="text" name="anio" class="form-control" id="anio" rows="3" 
          value="{{ old('anio', $curso->anio) }}">
          
          @if ($errors->has('anio'))
            <p>{{ $errors->first('anio') }}</p>
          @endif
        </div>

      <div class="mb-3">
        <label for="exampleFormControlInput1" class="form-label">Ciclo: </label>
        <input type="text" name="ciclo" class="form-control" id="ciclo" rows="3" 
        value="{{ old('ciclo', $curso->ciclo) }}">
        
        @if ($errors->has('ciclo'))
          <p>{{ $errors->first('ciclo') }}</p>
        @endif
      </div>

      <div class="mb-3">
        <label class="form-label">Código Profesor: </label>
        <select class="form-select" name="idprofesor">
          <option value="">-Seleccione Profesor</option>
          
          @foreach ($categoria as $categorias)
            <option value="{{ $categorias['idprofesor'] }}">{{ $categorias['nombre'] }}</option>
              
          @endforeach
        </select>
      </div>
        <button type="submit" class="btn btn-primary">Actualizar Curso</button>
        <a href="{{ route('curso.index') }}" type="submit" class="btn btn-danger">Regresar</a>
    </form>
    
@endsection