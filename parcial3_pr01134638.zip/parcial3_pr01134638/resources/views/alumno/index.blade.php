@extends('layout')
@section('title')
@section('content')
<br>
<div class="d-flex justify-content-between">
    <h2>ESTUDIANTES</h2>
<p>
    <a class="btn btn-primary" href="{{ route('alumno.create') }}">Nuevo Estudiante</a>
</p>
</div>

<table class="table" id="example">
    <thead class="thead-dark">
        
        <tr>
            <th scope="col">ID</th>
            <th scope="col">ESTUDIANTES</th>
            <th scope="col">ACCIONES</th>
        </tr>
    </thead>
    <tbody>
    @foreach ($alumnos as $alumno)
        <tr>
        <td>
            {{$alumno->idalumno }}
        </td>

        <td><a href="{{route('alumno.show', $alumno->idalumno)}}"> {{$alumno->nombre }}
        </td></a>
              
        <td><a href="{{ route('alumno.edit', $alumno->idalumno) }}"><span class="oi oi-pencil"></span></a>
            <form style="display: inline;" action="{{ route('alumno.destroy', $alumno->idalumno) }}" method="POST">
            {!! method_field('DELETE') !!}
            {!! csrf_field() !!}
            <button class="btn btn-link" type="submit"><span class="oi oi-trash"></span></button>
        </form>
        </td>        
        </tr>
    @endforeach
    </tbody>

</table>
@endsection

