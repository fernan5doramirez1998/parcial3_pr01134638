@extends('layout')
@section('content')



<h2>Estudiante: {{$alumno->nombre }}</h2>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th>ID</th>
            <th>NOMBRE</th>
            <th>APELLIDO</th>
            <th>NACIMIENTO</th>
            <th>DIRECCIÓN</th>
            <th>GÉNERO</th>
            <th>TELÉFONO</th>
            <th>EMAIL</th>
           
        </tr>
    </thead>
    <tbody>
        <th>
            {{$alumno->idalumno }}
        </th>
        <th>
            {{$alumno->nombre }}
        </th>
        <th>
            {{$alumno->apellido }}
        </th>
        <th>
            {{$alumno->fechanacimiento }}
        </th>
        <th>
            {{$alumno->direccion }}
        </th>
        <th>
            {{$alumno->genero }}
        </th>
        <th>
            {{$alumno->telefono }}
        </th>
        <th>
            {{$alumno->direccion }}
        </th>
       
    </tbody>
       
</table>
<div class="d-flex justify-content-between">
    <p>
       <a class="btn btn-primary" href="{{ route('alumno.index') }}">Regresar al listado de Estudiantes.</a>
   </p>
</div>
@endsection




