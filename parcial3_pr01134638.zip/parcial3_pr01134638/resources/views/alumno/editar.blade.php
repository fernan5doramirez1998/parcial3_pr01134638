@extends('layout')
@section('title', 'Editar Alumno')
@section('content')
    <br>
    <h1>Editar Estudiante</h1>

    @if ($errors->any())
    <div class="alert alert-danger">
      <h6>Por favor complete los campos requeridos:</h6>
      <ul>
        @foreach ($errors->all() as $error)
          <li>{{ $error }}</li>
        @endforeach
      </ul>
    </div>
    @endif



    <form method="POST" action="{{ route('alumno.update', $alumno->idalumno) }}">
      {!! method_field('PUT') !!}
      {!! csrf_field() !!}

      <div class="mb-3">
        <label for="exampleFormControlInput1" class="form-label">Nombre: </label>
        <input type="text" name="nombre" class="form-control" id="nombre" rows="3" placeholder="Ejemplo: Cristofer"
        value="{{ old('nombre', $alumno->nombre) }}">
        
        @if ($errors->has('nombre'))
          <p>{{ $errors->first('nombre') }}</p>
        @endif
      </div>
      <div class="mb-3">
        <label for="exampleFormControlTextarea1" class="form-label">Apellido</label>
        <input type="text" name="apellido" class="form-control" id="apellido" rows="3" placeholder="Ejemplo : Martínez"
        value="{{ old('apellido', $alumno->apellido) }}">
        @if ($errors->has('apellido'))
        <p>{{ $errors->first('apellido') }}</p>
        @endif
      </div>

      <div class="mb-3">
        <label for="exampleFormControlTextarea1" class="form-label">Fecha de nacimiento</label>
        <input type="date" name="fechanacimiento" class="form-control" id="fechanacimiento" rows="3" 
        value="{{ old('fechanacimiento', $alumno->fechanacimiento) }}">
        @if ($errors->has('fechanacimiento'))
        <p>{{ $errors->first('fechanacimiento') }}</p>
        @endif
      </div>
      <div class="mb-3">
        <label for="exampleFormControlTextarea1" class="form-label">Dirección</label>
        <input type="text" name="direccion" class="form-control" id="direccion" rows="3" placeholder="Colonia Montserrat, San Salvador"
        value="{{ old('direccion', $alumno->direccion) }}">
        @if ($errors->has('direccion'))
        <p>{{ $errors->first('direccion') }}</p>
        @endif
      </div>

      <div class="mb-3">
        <label for="exampleFormControlTextarea1" class="form-label">Género: </label>
        <select class="form-select" name="genero" rows="3">
          <option value="{{ old('genero', $alumno->genero) }}">-Seleccione Género</option>
            <option value="M">M</option>
            <option value="F">F</option>  
        </select>
      </div>




      {{-- <div class="mb-3">
        <label for="exampleFormControlTextarea1" class="form-label">Género</label>
        <input type="text" name="genero" class="form-control" id="genero" rows="3" 
        value="{{ old('genero', $alumno->genero) }}">
        @if ($errors->has('genero'))
        <p>{{ $errors->first('genero') }}</p>
        @endif
      </div> --}}
      <div class="mb-3">
        <label for="exampleFormControlTextarea1" class="form-label">Teléfono</label>
        <input type="text" name="telefono" class="form-control" id="telefono" rows="3" placeholder="+503 22459876"
        value="{{ old('telefono', $alumno->telefono) }}">
        @if ($errors->has('telefono'))
        <p>{{ $errors->first('telefono') }}</p>
        @endif
      </div>
      <div class="mb-3">
        <label for="exampleFormControlTextarea1" class="form-label">Email</label>
        <input type="text" name="correo" class="form-control" id="correo" rows="3" placeholder="email@example.com"
        value="{{ old('correo', $alumno->correo) }}">
        @if ($errors->has('correo'))
        <p>{{ $errors->first('correo') }}</p>
        @endif
      </div>
    
      <div class="mb-3">
        <label for="inputPassword" class="form-label">Clave</label>
        <input type="password" name="clave" class="form-control" id="clave" rows="3" placeholder="Mayor a 6 caracteres.">
        @if ($errors->has('clave'))
          <p>{{ $errors->first('clave') }}</p>
        @endif
      </div>    
      <button type="submit" class="btn btn-primary">Actualizar Estudiante</button>
      <a href="{{ route('alumno.index') }}" type="submit" class="btn btn-danger">Regresar</a>
  </form>
    
@endsection