@extends('layout')
@section('title', 'Editar Usuario')
@section('content')
    <br>
    <h1>Editar Usuario</h1>

    @if ($errors->any())
    <div class="alert alert-danger">
      <h6>Por favor complete los campos requeridos:</h6>
      <ul>
        @foreach ($errors->all() as $error)
          <li>{{ $error }}</li>
        @endforeach
      </ul>
    </div>
    @endif


    <form method="POST" action="{{ route('users.update', $user->id) }}">
      {!! method_field('PUT') !!}
      {!! csrf_field() !!}

      <div class="mb-3">
        <label for="exampleFormControlInput1" class="form-label">Nombre: </label>
        <input type="text" name="name" class="form-control" id="name" rows="3" 
        value="{{ old('name', $user->name) }}">
        
        @if ($errors->has('name'))
          <p>{{ $errors->first('name') }}</p>
        @endif
      </div>
      <div class="mb-3">
        <label for="exampleFormControlTextarea1" class="form-label">Email</label>
        <input type="text" name="email" class="form-control" id="email" rows="3" 
        value="{{ old('email', $user->email) }}">
        @if ($errors->has('email'))
        <p>{{ $errors->first('email') }}</p>
        @endif
      </div>

      <div class="mb-3">
        <label for="exampleFormControlTextarea1" class="form-label">Role</label>
        <input type="text" name="role" class="form-control" id="role" rows="3" 
        value="{{ old('role', $user->role) }}">
        @if ($errors->has('role'))
        <p>{{ $errors->first('role') }}</p>
        @endif
      </div>

         
      <div class="mb-3">
        <label for="inputPassword" class="form-label">Password</label>
        <input type="password" name="password" class="form-control" id="clave" rows="3" placeholder="Mayor a 6 caracteres.">
        @if ($errors->has('password'))
          <p>{{ $errors->first('password') }}</p>
        @endif
      </div>    
     
      <button type="submit" class="btn btn-primary">Editar Usuario</button>
  </form>
    
@endsection