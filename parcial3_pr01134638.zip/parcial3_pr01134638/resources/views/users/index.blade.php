@extends('layout')
@section('title')
@section('content')
<br>
<div class="d-flex justify-content-between">
    <h2>Usuarios</h2>
<p>
    <a class="btn btn-primary" href="{{ route('users.create') }}">Nuevo Usuario</a>
</p>
</div>

<table class="table" id="example">
    <thead class="thead-dark">
        
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Usuario</th>
            <th scope="col">ROL</th>
            <th scope="col">ACCIONES</th>
        </tr>
    </thead>
    <tbody>
    @foreach ($users as $user)
        <tr>
        <td>
            {{$user->id }}
        </td>

        <td><a> {{$user->name }}
        </td></a>

        <td>
                {{$user->role }}
            </td>
              
        <td><a href="{{ route('users.edit', $user->id) }}"><span class="oi oi-pencil"></span></a>
            <form style="display: inline;" action="{{ route('users.destroy', $user->id) }}" method="POST">
            {!! method_field('DELETE') !!}
            {!! csrf_field() !!}
            <button class="btn btn-link" type="submit"><span class="oi oi-trash"></span></button>
        </form>
        </td>        
        </tr>
    @endforeach
    </tbody>

</table>
@endsection

