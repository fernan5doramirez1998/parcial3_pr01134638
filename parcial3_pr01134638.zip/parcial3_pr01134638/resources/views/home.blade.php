@extends('layouts.app')

@section('content')

<h1>Bienvenidos!!!</h1>

@endsection
