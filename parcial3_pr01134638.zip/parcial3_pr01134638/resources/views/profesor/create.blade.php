@extends('layout')
@section('title', "Crear Profesor")
@section('content')
    <h1>Crear Profesor</h1>

    @if ($errors->any())
    <div class="alert alert-danger">
      <h6>Por favor complete los campos requeridos:</h6>
      <ul>
        @foreach ($errors->all() as $error)
          <li>{{ $error }}</li>
        @endforeach
      </ul>
    </div>
    @endif

    <form method="POST" action="{{ route('profesor.store') }}">
       
        {!! csrf_field() !!}

        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Nombre: </label>
          <input type="text" name="nombre" class="form-control" id="nombre" rows="3" placeholder="Ejemplo: Lic.Cristofer"
          value="{{ old('nombre') }}">
          
          @if ($errors->has('nombre'))
            <p>{{ $errors->first('nombre') }}</p>
          @endif
        </div>
        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Apellido</label>
          <input type="text" name="apellido" class="form-control" id="apellido" rows="3" placeholder="Ejemplo : Martínez"
          value="{{ old('apellido') }}">
          @if ($errors->has('apellido'))
          <p>{{ $errors->first('apellido') }}</p>
          @endif
        </div>

        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">DUI</label>
          <input type="text" name="dui" class="form-control" id="dui" rows="3" placeholder="75096310-2"
          value="{{ old('dui') }}">
          @if ($errors->has('dui'))
          <p>{{ $errors->first('dui') }}</p>
          @endif
        </div>

        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Teléfono</label>
          <input type="text" name="telefono" class="form-control" id="telefono" rows="3" placeholder="+503 22459876"
          value="{{ old('telefono') }}">
          @if ($errors->has('telefono'))
          <p>{{ $errors->first('telefono') }}</p>
          @endif
        </div>
        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Email</label>
          <input type="text" name="email" class="form-control" id="email" rows="3" placeholder="email@example.com"
          value="{{ old('email') }}">
          @if ($errors->has('email'))
          <p>{{ $errors->first('email') }}</p>
          @endif
        </div>
      
        <div class="mb-3">
          <label for="inputPassword" class="form-label">Clave</label>
          <input type="password" name="clave" class="form-control" id="clave" rows="3" placeholder="Mayor a 6 caracteres.">
          @if ($errors->has('clave'))
            <p>{{ $errors->first('clave') }}</p>
          @endif
        </div>    
       
        <button type="submit" class="btn btn-primary">Crear Profesor</button>
    </form>
    
@endsection