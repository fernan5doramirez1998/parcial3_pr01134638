@extends('layout')
@section('content')



<h2>Profesor: {{$profesor->nombre }}</h2>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th>ID</th>
            <th>NOMBRE</th>
            <th>APELLIDO</th>
            <th>DUI</th>
            <th>TELÉFONO</th>
            <th>EMAIL</th>

        </tr>
    </thead>
    <tbody>
        <th>
            {{$profesor->idprofesor }}
        </th>
        <th>
            {{$profesor->nombre }}
        </th>
        <th>
            {{$profesor->apellido }}
        </th>
        <th>
            {{$profesor->dui }}
        </th>
        <th>
            {{$profesor->telefono }}
        </th>
        <th>
            {{$profesor->email }}
        </th>

    </tbody>
       
</table>
<div class="d-flex justify-content-between">
    <p>
       <a class="btn btn-primary" href="{{ route('profesor.index') }}">Regresar al listado de Profesores.</a>
   </p>
</div>
@endsection




