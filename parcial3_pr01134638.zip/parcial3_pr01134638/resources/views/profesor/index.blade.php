@extends('layout')
@section('title')
@section('content')
<br>
<div class="d-flex justify-content-between">
    <h2>PROFESORES</h2>
<p>
    <a class="btn btn-primary" href="{{ route('profesor.create') }}">Nuevo Profesor</a>
</p>
</div>

<table class="table" id="example">
    <thead class="thead-dark">
        
        <tr>
            <th scope="col">ID</th>
            <th scope="col">PROFESORES</th>
            <th scope="col">ACCIONES</th>
        </tr>
    </thead>
    <tbody>
    @foreach ($profesors as $profesor)
        <tr>
        <td>
            {{$profesor->idprofesor }}
        </td>

        <td><a href="{{route('profesor.show', $profesor->idprofesor)}}"> {{$profesor->nombre }}
        </td></a>
              
        <td><a href="{{ route('profesor.edit', $profesor->idprofesor) }}"><span class="oi oi-pencil"></span></a>
            <form style="display: inline;" action="{{ route('profesor.destroy', $profesor->idprofesor) }}" method="POST">
            {!! method_field('DELETE') !!}
            {!! csrf_field() !!}
            <button class="btn btn-link" type="submit"><span class="oi oi-trash"></span></button>
        </form>
        </td>        
        </tr>
    @endforeach
    </tbody>

</table>
@endsection

