@extends('layout')
@section('content')


{{-- @foreach ($categoria as $categorias)
<h2>Estudiante: {{$categorias['nombre'] }}</h2>
@endforeach --}}
{{-- <h2>Profesor: {{ $categorias1['nombre'] }}</h2> --}}
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th>Alumno</th>
            <th>Curso</th>
            <th>Nota 1</th>
            <th>Nota 2</th>
            <th>Nota 3</th>
            <th>Nota 4</th>
            <th>Parcial</th>
            <th>Promedio</th>

        </tr>
    </thead>
    <tbody>
        <th>
            {{$nota->profesor->nombre }}
        </th>
        {{-- <th>
            {{$nota->nota1 }}
        </th>
        <th>
            {{$nota->nota2 }}
        </th>
        <th>
            {{$nota->nota3 }}
        </th>
        <th>
            {{$nota->nota4 }}
        </th>
        <th>
            {{$nota->parcial }}
        </th>
        <th>
            {{$nota->promedio }}
        </th> --}}

    </tbody>
       
</table>
<div class="d-flex justify-content-between">
    <p>
       <a class="btn btn-primary" href="{{ route('nota.index') }}">Regresar.</a>
   </p>
</div>
@endsection




