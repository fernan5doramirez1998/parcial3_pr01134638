@extends('layout')
@section('title', "Ingresar Notas")
@section('content')
    <h2>Estudiante: {{$alumno->nombre }}</h2>
    <h1>Ingresar Notas</h1>

    @if ($errors->any())
    <div class="alert alert-danger">
      <h6>Por favor complete los campos requeridos:</h6>
      <ul>
        @foreach ($errors->all() as $error)
          <li>{{ $error }}</li>
        @endforeach
      </ul>
    </div>
    @endif

    <form method="POST" action="{{ route('nota.store') }}">
       
        {!! csrf_field() !!}

        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Nota 1: </label>
          <input type="text" name="nota1" class="form-control" id="nota1" rows="3"
          value="{{ old('nota1') }}">
          
          @if ($errors->has('nota1'))
            <p>{{ $errors->first('nota1') }}</p>
          @endif
        </div>
        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Nota 2:</label>
          <input type="text" name="nota2" class="form-control" id="nota2" rows="3" 
          value="{{ old('nota2') }}">
          @if ($errors->has('nota2'))
          <p>{{ $errors->first('nota2') }}</p>
          @endif
        </div>

        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Nota 3:</label>
          <input type="text" name="nota3" class="form-control" id="nota3" rows="3" 
          value="{{ old('nota3') }}">
          @if ($errors->has('nota3'))
          <p>{{ $errors->first('nota3') }}</p>
          @endif
        </div>

        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Nota 4:</label>
          <input type="text" name="nota4" class="form-control" id="nota4" rows="3" 
          value="{{ old('nota4') }}">
          @if ($errors->has('nota4'))
          <p>{{ $errors->first('nota4') }}</p>
          @endif
        </div>

        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Parcial:</label>
          <input type="text" name="parcial" class="form-control" id="parcial" rows="3" 
          value="{{ old('parcial') }}">
          @if ($errors->has('parcial'))
          <p>{{ $errors->first('parcial') }}</p>
          @endif
        </div>

        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Promedio:</label>
          <input type="text" name="promedio" class="form-control" id="promedio" rows="3" 
          value="{{ old('promedio') }}">
          @if ($errors->has('promedio'))
          <p>{{ $errors->first('promedio') }}</p>
          @endif
        </div>

        <div class="mb-3">
          <label class="form-label">Alumno: </label>
          <select class="form-select" name="idalumno">
            <option value="">-Seleccione Alumno</option>
            @foreach ($categoria as $categorias)
              <option value="{{ $categorias['idalumno'] }}">{{ $categorias['nombre'] }}</option>
                
            @endforeach
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label">Profesor: </label>
          <select class="form-select" name="idprofesor">
            <option value="">-Seleccione Profesor</option>
            @foreach ($categoria1 as $categorias1)
              <option value="{{ $categorias1['idprofesor'] }}">{{ $categorias1['nombre'] }}</option>
                
            @endforeach
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label">Curso: </label>
          <select class="form-select" name="idcurso">
            <option value="">-Seleccione Curso</option>
            @foreach ($categoria2 as $categorias2)
              <option value="{{ $categorias2['idcurso'] }}">{{ $categorias2['nombrecurso'] }}</option>
                
            @endforeach
          </select>
        </div>

       
        <button type="submit" class="btn btn-primary">Ingresar Notas</button>
    </form>
    
@endsection