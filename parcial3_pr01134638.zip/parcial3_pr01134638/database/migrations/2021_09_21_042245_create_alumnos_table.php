<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAlumnosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //Agregando campos a la tabla alumnos
        Schema::create('alumnos', function (Blueprint $table) {
            $table->increments('idalumno');
            $table->string('nombre',150);
            $table->string('apellido',150);
            $table->date('fechanacimiento',50);
            $table->string('dirección',250);
            $table->string('genero',50);
            $table->string('telefono',150);
            $table->string('correo',150);
            $table->string('clave',150);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('alumnos');
    }
}
