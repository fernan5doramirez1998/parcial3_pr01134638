<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateNotasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
         //Agregando campos a la tabla notas
         Schema::create('notas', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('idnotas');
            $table->decimal('nota1',15);
            $table->decimal('nota2',15);
            $table->decimal('nota3',15);
            $table->decimal('nota4',15);
            $table->decimal('promedio',15);
            $table->decimal('parcial',15);
            //Estos campos seran agregados después por ser llaves foráneas

            // $table->integer('idalumno')->unsigned();
            // $table->foreign('idalumno')->references('idalumno')->on('alumnos');
            // $table->integer('idprofesor')->unsigned();
            // $table->foreign('idprofesor')->references('idprofesor')->on('profesor');
            // $table->integer('idcursos')->unsigned();
            // $table->foreign('idcursos')->references('idcursos')->on('cursos');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('notas');
    }
}
