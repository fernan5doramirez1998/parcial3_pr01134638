<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddForeignKeyNotasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('notas', function (Blueprint $table) {
            //Agregando los campos idalumno, idprofesor, idcursos a la tabla notas
            $table->integer('idalumno')->unsigned();
            $table->foreign('idalumno')->references('idalumno')->on('alumnos');
            $table->integer('idcursos')->unsigned();
            $table->foreign('idcursos')->references('idcursos')->on('cursos');
            $table->integer('idprofesor')->unsigned();
            $table->foreign('idprofesor')->references('idprofesor')->on('profesor');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
