<?php

use Illuminate\Database\Seeder;

class CursoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // ///Constructor de Laravel
        // DB::table('cursos')->insert([
        //     'nombrecurso'=>'Programación III',
        //     'anio'=>'2021',
        //     'ciclo'=>'2',        
        //     'idprofesor'=>'1',
        //      ]);

        // //Sentencia sql
        // DB::insert('INSERT INTO cursos (nombrecurso, anio, ciclo, idprofesor)
        // VALUES (?,?,?,?)', ['Redes II', '2021', '2', '1',]);
    }
}
