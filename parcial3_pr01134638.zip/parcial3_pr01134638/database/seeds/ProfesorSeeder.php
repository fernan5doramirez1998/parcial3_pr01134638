<?php

use Illuminate\Database\Seeder;
use App\Profesor;
use Faker\Factory;
class ProfesorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //Constructor de Laravel

        // DB::table('profesor')->insert([
        //     'nombre'=>'Jorge Alberto',
        //     'apellido'=>'Coto Zelaya',
        //     'dui'=>'96543810-5',        
        //     'telefono'=>'7577-9087',
        //     'email'=>'coto@gmail.com',
        //     'clave'=> bcrypt('jorge2021'),
        //      ]);

        //Sentencia sql
        
        // DB::insert('INSERT INTO profesor (nombre, apellido, dui, telefono,
        //     email, clave) VALUES (?,?,?,?,?,?)', ['Andrés', 'Romero',
        //     '06754398-6', '7354-1973', 'romero@gmail.com', bcrypt('123456'),
        //     ]);

        //Agregando registros por factory
        //factory(Profesor::class, 18)->create();

    }
}
