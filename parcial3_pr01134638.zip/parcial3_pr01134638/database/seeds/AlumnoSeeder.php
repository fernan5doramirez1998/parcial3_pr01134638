<?php

use Illuminate\Database\Seeder;

use App\Alumno;
use Faker\Factory;
class AlumnoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //Constructor de Laravel

        // DB::table('alumnos')->insert([
        //     'nombre'=>'Cristian Daniel',
        //     'apellido'=>'Gómez Arana',
        //     'fechanacimiento'=>'1998-12-09',
        //     'dirección'=>'Comunidad los Robles, La Paz',
        //     'genero'=>'Masculino',
        //     'telefono'=>'2296-9087',
        //     'correo'=>'gomez@gmail.com',
        //     'clave'=> bcrypt('cristian2021'),
        //      ]);

        //Sentencias sql
         
        // DB::insert('INSERT INTO alumnos (nombre, apellido, fechanacimiento, dirección,
        //     genero, telefono, correo, clave) VALUES (?,?,?,?,?,?,?,?)', ['Fernando', 'Ramírez',
        //     '1999-03-05', 'Colonia Montelimar', 'M', '2254-5678', 'fer@gmail.com', bcrypt('123')]);


        //Eloquent
        // Alumno::create(
        //     [
        //         'nombre' => 'Yovani',
        //         'apellido' => 'Martínez',
        //         'fechanacimiento' => '1989-12-12',
        //         'dirección' => 'Comunidad El comercio,San Miguel',
        //         'genero' => 'M',
        //         'telefono' => '6453-9843',
        //         'correo' => 'yovani@gmail.com',
        //         'clave' => bcrypt('123')                   
        //      ] 
        // );
         //Insertando datos atraves de factory
         //factory(Alumno::class, 18)->create();
    }
}
