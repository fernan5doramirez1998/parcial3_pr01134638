<?php

use Illuminate\Database\Seeder;

class NotaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //Constructor de Laravel

        // DB::table('notas')->insert([
        //     'nota1'=>'10',
        //     'nota2'=>'10',
        //     'nota3'=>'10',
        //     'nota4'=>'9',
        //     'promedio'=>'9.5',
        //     'parcial'=>'10',
        //     'idalumno'=>'1',
        //     'idcursos'=>'1',
        //     'idprofesor'=>'1',
        //      ]);

        //Sentencia sql
        //Sentencia sql
        
        // DB::insert('INSERT INTO notas (nota1, nota2, nota3, nota4,
        //     promedio, parcial, idalumno, idcursos, idprofesor) VALUES (?,?,?,?,?,?,?,?,?)', ['9', '10',
        //     '8', '10', '8', '10', '1','1','1']);

        

    }
}
