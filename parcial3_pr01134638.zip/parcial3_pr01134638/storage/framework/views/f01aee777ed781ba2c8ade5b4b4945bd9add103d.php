<?php $__env->startSection('title'); ?>
<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between">
    <h1>Cursos</h1>
<p>
    <a class="btn btn-primary" href="<?php echo e(route('curso.create')); ?>">Nuevo Curso</a>
</p>
</div>

<table class="table">
    <thead class="thead-dark">
        
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Curso</th>
            <th scope="col">Acciones</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td>
            <?php echo e($curso->idcurso); ?>

        </td>
        
             
        <td><a href="<?php echo e(route('curso.show', $curso->idcurso)); ?>"> <?php echo e($curso->nombrecurso); ?>

        </td></a>
              
        <td><a href="<?php echo e(route('curso.edit', $curso->idcurso)); ?>"><span class="oi oi-pencil"></span></a>
            <form style="display: inline;" action="<?php echo e(route('curso.destroy', $curso->idcurso)); ?>" method="POST">
            <?php echo method_field('DELETE'); ?>

            <?php echo csrf_field(); ?>

            <button class="btn btn-link" type="submit"><span class="oi oi-trash"></span></button>
        </form>
        </td>         
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

</table>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>