<?php $__env->startSection('content'); ?>



<h2>Profesor: <?php echo e($profesor->nombre); ?></h2>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th>ID</th>
            <th>NOMBRE</th>
            <th>APELLIDO</th>
            <th>DUI</th>
            <th>TELÉFONO</th>
            <th>EMAIL</th>

        </tr>
    </thead>
    <tbody>
        <th>
            <?php echo e($profesor->idprofesor); ?>

        </th>
        <th>
            <?php echo e($profesor->nombre); ?>

        </th>
        <th>
            <?php echo e($profesor->apellido); ?>

        </th>
        <th>
            <?php echo e($profesor->dui); ?>

        </th>
        <th>
            <?php echo e($profesor->telefono); ?>

        </th>
        <th>
            <?php echo e($profesor->email); ?>

        </th>

    </tbody>
       
</table>
<div class="d-flex justify-content-between">
    <p>
       <a class="btn btn-primary" href="<?php echo e(route('profesor.index')); ?>">Regresar al listado de Profesores.</a>
   </p>
</div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>