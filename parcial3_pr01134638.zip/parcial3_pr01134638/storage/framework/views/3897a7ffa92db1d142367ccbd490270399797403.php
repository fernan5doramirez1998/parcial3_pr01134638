<?php $__env->startSection('title'); ?>
<?php $__env->startSection('content'); ?>
<br>
<div class="d-flex justify-content-between">
    <h2>PROFESORES</h2>
<p>
    <a class="btn btn-primary" href="<?php echo e(route('profesor.create')); ?>">Nuevo Profesor</a>
</p>
</div>

<table class="table" id="example">
    <thead class="thead-dark">
        
        <tr>
            <th scope="col">ID</th>
            <th scope="col">PROFESORES</th>
            <th scope="col">ACCIONES</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $profesors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profesor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td>
            <?php echo e($profesor->idprofesor); ?>

        </td>

        <td><a href="<?php echo e(route('profesor.show', $profesor->idprofesor)); ?>"> <?php echo e($profesor->nombre); ?>

        </td></a>
              
        <td><a href="<?php echo e(route('profesor.edit', $profesor->idprofesor)); ?>"><span class="oi oi-pencil"></span></a>
            <form style="display: inline;" action="<?php echo e(route('profesor.destroy', $profesor->idprofesor)); ?>" method="POST">
            <?php echo method_field('DELETE'); ?>

            <?php echo csrf_field(); ?>

            <button class="btn btn-link" type="submit"><span class="oi oi-trash"></span></button>
        </form>
        </td>        
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

</table>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>