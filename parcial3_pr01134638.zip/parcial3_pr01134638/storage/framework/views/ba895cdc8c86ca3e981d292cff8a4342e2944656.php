<?php $__env->startSection('title', "Crear Profesor"); ?>
<?php $__env->startSection('content'); ?>
    <h1>Crear Profesor</h1>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
      <h6>Por favor complete los campos requeridos:</h6>
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('profesor.store')); ?>">
       
        <?php echo csrf_field(); ?>


        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Nombre: </label>
          <input type="text" name="nombre" class="form-control" id="nombre" rows="3" placeholder="Ejemplo: Lic.Cristofer"
          value="<?php echo e(old('nombre')); ?>">
          
          <?php if($errors->has('nombre')): ?>
            <p><?php echo e($errors->first('nombre')); ?></p>
          <?php endif; ?>
        </div>
        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Apellido</label>
          <input type="text" name="apellido" class="form-control" id="apellido" rows="3" placeholder="Ejemplo : Martínez"
          value="<?php echo e(old('apellido')); ?>">
          <?php if($errors->has('apellido')): ?>
          <p><?php echo e($errors->first('apellido')); ?></p>
          <?php endif; ?>
        </div>

        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">DUI</label>
          <input type="text" name="dui" class="form-control" id="dui" rows="3" placeholder="75096310-2"
          value="<?php echo e(old('dui')); ?>">
          <?php if($errors->has('dui')): ?>
          <p><?php echo e($errors->first('dui')); ?></p>
          <?php endif; ?>
        </div>

        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Teléfono</label>
          <input type="text" name="telefono" class="form-control" id="telefono" rows="3" placeholder="+503 22459876"
          value="<?php echo e(old('telefono')); ?>">
          <?php if($errors->has('telefono')): ?>
          <p><?php echo e($errors->first('telefono')); ?></p>
          <?php endif; ?>
        </div>
        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Email</label>
          <input type="text" name="email" class="form-control" id="email" rows="3" placeholder="email@example.com"
          value="<?php echo e(old('email')); ?>">
          <?php if($errors->has('email')): ?>
          <p><?php echo e($errors->first('email')); ?></p>
          <?php endif; ?>
        </div>
      
        <div class="mb-3">
          <label for="inputPassword" class="form-label">Clave</label>
          <input type="password" name="clave" class="form-control" id="clave" rows="3" placeholder="Mayor a 6 caracteres.">
          <?php if($errors->has('clave')): ?>
            <p><?php echo e($errors->first('clave')); ?></p>
          <?php endif; ?>
        </div>    
       
        <button type="submit" class="btn btn-primary">Crear Profesor</button>
    </form>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>