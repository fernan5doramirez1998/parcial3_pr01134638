<?php $__env->startSection('content'); ?>




<table class="table">
    <thead class="thead-dark">
        <tr>
            <th>Alumno</th>
            <th>Curso</th>
            <th>Nota 1</th>
            <th>Nota 2</th>
            <th>Nota 3</th>
            <th>Nota 4</th>
            <th>Parcial</th>
            <th>Promedio</th>

        </tr>
    </thead>
    <tbody>
        <th>
            <?php echo e($nota->profesor->nombre); ?>

        </th>
        

    </tbody>
       
</table>
<div class="d-flex justify-content-between">
    <p>
       <a class="btn btn-primary" href="<?php echo e(route('nota.index')); ?>">Regresar.</a>
   </p>
</div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>