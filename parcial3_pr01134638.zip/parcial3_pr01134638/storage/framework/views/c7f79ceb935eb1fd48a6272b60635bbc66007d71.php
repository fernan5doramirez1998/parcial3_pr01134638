<?php $__env->startSection('content'); ?>



<h2>Cursos</h2>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th>ID</th>
            <th>CURSO</th>
            <th>AÑO</th>
            <th>CICLO</th>
            <th>PROFESOR</th>
            
        </tr>
    </thead>
    <tbody>
        <th>
            <?php echo e($curso->idcurso); ?>

        </th>
        <th>
            <?php echo e($curso->nombrecurso); ?>

        </th>
        <th>
            <?php echo e($curso->anio); ?>

        </th>
        <th>
            <?php echo e($curso->ciclo); ?>

        </th>
        <th>
            <?php echo e($curso->profesor->nombre); ?>

        </th>
        
    </tbody>
       
</table>
<div class="d-flex justify-content-between">
    <p>
       <a class="btn btn-primary" href="<?php echo e(route('curso.index')); ?>">Regresar al listado de Cursos.</a>
   </p>
</div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>