<?php $__env->startSection('title'); ?>
<?php $__env->startSection('content'); ?>
<br>
<div class="d-flex justify-content-between">
    <h2>ESTUDIANTES</h2>
<p>
    <a class="btn btn-primary" href="<?php echo e(route('alumno.create')); ?>">Nuevo Estudiante</a>
</p>
</div>

<table class="table" id="example">
    <thead class="thead-dark">
        
        <tr>
            <th scope="col">ID</th>
            <th scope="col">ESTUDIANTES</th>
            <th scope="col">ACCIONES</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td>
            <?php echo e($alumno->idalumno); ?>

        </td>

        <td><a href="<?php echo e(route('alumno.show', $alumno->idalumno)); ?>"> <?php echo e($alumno->nombre); ?>

        </td></a>
              
        <td><a href="<?php echo e(route('alumno.edit', $alumno->idalumno)); ?>"><span class="oi oi-pencil"></span></a>
            <form style="display: inline;" action="<?php echo e(route('alumno.destroy', $alumno->idalumno)); ?>" method="POST">
            <?php echo method_field('DELETE'); ?>

            <?php echo csrf_field(); ?>

            <button class="btn btn-link" type="submit"><span class="oi oi-trash"></span></button>
        </form>
        </td>        
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

</table>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>