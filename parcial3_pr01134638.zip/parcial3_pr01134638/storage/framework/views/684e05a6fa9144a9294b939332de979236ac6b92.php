
<!doctype html>
<html lang="en" class="h-100">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.87.0">
    <title>  <?php echo $__env->yieldContent('title'); ?> -SGE NOTAS</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/sticky-footer-navbar/">

    

    <!-- Bootstrap core CSS -->
    

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    
    

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/open-iconic/1.1.1/font/css/open-iconic.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/open-iconic/1.1.1/font/css/open-iconic-bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/open-iconic/1.1.1/font/css/open-iconic-foundation.min.css">

<!-- datatable en pdf-->
<link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.0.1/css/buttons.dataTables.min.css">    

       <!-- Favicons -->
<link rel="apple-touch-icon" href="/docs/5.1/assets/img/favicons/apple-touch-icon.png" sizes="180x180">
<link rel="icon" href="/docs/5.1/assets/img/favicons/favicon-32x32.png" sizes="32x32" type="image/png">
<link rel="icon" href="/docs/5.1/assets/img/favicons/favicon-16x16.png" sizes="16x16" type="image/png">
<link rel="manifest" href="/docs/5.1/assets/img/favicons/manifest.json">
<link rel="mask-icon" href="/docs/5.1/assets/img/favicons/safari-pinned-tab.svg" color="#7952b3">
<link rel="icon" href="/docs/5.1/assets/img/favicons/favicon.ico">
<meta name="theme-color" content="#7952b3">


    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }

      main > .container {
  padding: 60px 15px 0;
}

      
    </style>

    
    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
  </head>
  <body class="d-flex flex-column h-100">
    
<header>
  <!-- Fixed navbar -->
  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">SGE NOTAS</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav me-auto mb-2 mb-md-0">
          <li class="navbar-nav">
            
            
            
            
            
            <?php if(auth()->check()): ?>
                
                
                <?php if(auth()->user()->hasRoles(['admin'])): ?>
                    
                    <a class="nav-link active" aria-current="page" href="<?php echo e(route('users.index')); ?>">Ver Usuarios</a>
                    <a class="nav-link active" aria-current="page" href="<?php echo e(route('curso.index')); ?>">Ver Cursos</a>
                    <a class="nav-link active" aria-current="page" href="<?php echo e(route('profesor.index')); ?>">Ver Profesores</a>
                    <a class="nav-link active" aria-current="page" href="<?php echo e(route('alumno.index')); ?>">Ver Estudiantes</a>
                    <a class="nav-link active" aria-current="page" href="/logout">Cerrar sesión de <?php echo e(auth()->user()->name); ?></a>
                
                <?php endif; ?>  

                <?php if(auth()->user()->hasRoles(['estudiante'])): ?>

                  <a class="nav-link active" aria-current="page" href="<?php echo e(route('curso.index')); ?>">Ver Cursos</a>
                  <a class="nav-link active" aria-current="page" href="<?php echo e(route('alumno.index')); ?>">Ver Estudiantes</a>
                  <a class="nav-link active" aria-current="page" href="/logout">Cerrar sesión de <?php echo e(auth()->user()->name); ?></a>
                  
            
                <?php endif; ?>  

                <?php if(auth()->user()->hasRoles(['profesor'])): ?>
                  
                  <a class="nav-link active" aria-current="page" href="<?php echo e(route('curso.index')); ?>">Ver Cursos</a>
                  <a class="nav-link active" aria-current="page" href="<?php echo e(route('profesor.index')); ?>">Ver Estudiantes</a>
                  <a class="nav-link active" aria-current="page" href="/logout">Cerrar sesión de <?php echo e(auth()->user()->name); ?></a>
            
                <?php endif; ?>  

            <?php endif; ?>           
            <?php if(auth()->guest()): ?>
              <a class="nav-link active" aria-current="page" href="<?php echo e(url('/login')); ?>">Login</a>
            <?php endif; ?>
            </li>
         
      </div>
    </div>
  </nav>
</header>

<!-- Begin page content -->
<main class="flex-shrink-0">

    <div class="container">

        <?php echo $__env->yieldContent('content'); ?>

    </div>

  </main>
  
  <footer class="footer mt-auto py-3 bg-light">
    <div class="container">
      <span class="text-muted">Copyright 2021, Todos los Derechos Reservados.</span>
    </div>
  </footer>
  
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


<script src="https://unpkg.com/ionicons@5.2.3/dist/ionicons.js"></script>

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.0.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.print.min.js"></script>

<script>

  $(document).ready(function() {
    $('#example').DataTable( {


      dom: 'Bfrtip',
      buttons: [
          'copy', 'csv', 'excel', 'pdf', 'print'
          
      ],
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.11.3/i18n/es_es.json"
        },

        "lengthMenu" : [[5,10, 50, -1], [5, 10, 50, "All"]]

    } );
} );

  
</script>



  </body>
</html>

