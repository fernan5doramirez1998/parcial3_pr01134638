<?php $__env->startSection('title', "Login"); ?>
<?php $__env->startSection('content'); ?>
    <h1>Login</h1>   
    <form method="POST" action="/login">
        <?php echo e(csrf_field()); ?>

        <input type="email" name="email" placeholder="Email">
        <input type="password" name="password" placeholder="Password">
        <input type="submit" value="Entrar">
    </form>
    <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>