<?php $__env->startSection('title', 'Editar Usuario'); ?>
<?php $__env->startSection('content'); ?>
    <br>
    <h1>Editar Usuario</h1>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
      <h6>Por favor complete los campos requeridos:</h6>
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>


    <form method="POST" action="<?php echo e(route('users.update', $user->id)); ?>">
      <?php echo method_field('PUT'); ?>

      <?php echo csrf_field(); ?>


      <div class="mb-3">
        <label for="exampleFormControlInput1" class="form-label">Nombre: </label>
        <input type="text" name="name" class="form-control" id="name" rows="3" 
        value="<?php echo e(old('name', $user->name)); ?>">
        
        <?php if($errors->has('name')): ?>
          <p><?php echo e($errors->first('name')); ?></p>
        <?php endif; ?>
      </div>
      <div class="mb-3">
        <label for="exampleFormControlTextarea1" class="form-label">Email</label>
        <input type="text" name="email" class="form-control" id="email" rows="3" 
        value="<?php echo e(old('email', $user->email)); ?>">
        <?php if($errors->has('email')): ?>
        <p><?php echo e($errors->first('email')); ?></p>
        <?php endif; ?>
      </div>

      <div class="mb-3">
        <label for="exampleFormControlTextarea1" class="form-label">Role</label>
        <input type="text" name="role" class="form-control" id="role" rows="3" 
        value="<?php echo e(old('role', $user->role)); ?>">
        <?php if($errors->has('role')): ?>
        <p><?php echo e($errors->first('role')); ?></p>
        <?php endif; ?>
      </div>

         
      <div class="mb-3">
        <label for="inputPassword" class="form-label">Password</label>
        <input type="password" name="password" class="form-control" id="clave" rows="3" placeholder="Mayor a 6 caracteres.">
        <?php if($errors->has('password')): ?>
          <p><?php echo e($errors->first('password')); ?></p>
        <?php endif; ?>
      </div>    
     
      <button type="submit" class="btn btn-primary">Editar Usuario</button>
  </form>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>