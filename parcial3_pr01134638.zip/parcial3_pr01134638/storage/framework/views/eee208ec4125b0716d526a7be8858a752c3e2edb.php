<?php $__env->startSection('title', "Crear Alumno"); ?>
<?php $__env->startSection('content'); ?>
    <h1>Crear Estudiante</h1>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
      <h6>Por favor complete los campos requeridos:</h6>
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('alumno.store')); ?>">
       
        <?php echo csrf_field(); ?>


        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Nombre: </label>
          <input type="text" name="nombre" class="form-control" id="nombre" rows="3" placeholder="Ejemplo: Cristofer"
          value="<?php echo e(old('nombre')); ?>">
          
          <?php if($errors->has('nombre')): ?>
            <p><?php echo e($errors->first('nombre')); ?></p>
          <?php endif; ?>
        </div>
        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Apellido</label>
          <input type="text" name="apellido" class="form-control" id="apellido" rows="3" placeholder="Ejemplo : Martínez"
          value="<?php echo e(old('apellido')); ?>">
          <?php if($errors->has('apellido')): ?>
          <p><?php echo e($errors->first('apellido')); ?></p>
          <?php endif; ?>
        </div>

        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Fecha de nacimiento</label>
          <input type="date" name="fechanacimiento" class="form-control" id="fechanacimiento" rows="3" 
          value="<?php echo e(old('fechanacimiento')); ?>">
          <?php if($errors->has('fechanacimiento')): ?>
          <p><?php echo e($errors->first('fechanacimiento')); ?></p>
          <?php endif; ?>
        </div>
        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Dirección</label>
          <input type="text" name="direccion" class="form-control" id="direccion" rows="3" placeholder="Colonia Montserrat, San Salvador"
          value="<?php echo e(old('direccion')); ?>">
          <?php if($errors->has('direccion')): ?>
          <p><?php echo e($errors->first('direccion')); ?></p>
          <?php endif; ?>
        </div>

        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Género: </label>
          <select class="form-select" name="genero" rows="3">
            <option value="">-Seleccione Género</option>
              <option value="M">M</option>
              <option value="F">F</option>  
          </select>
        </div>

        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Teléfono</label>
          <input type="text" name="telefono" class="form-control" id="telefono" rows="3" placeholder="+503 22459876"
          value="<?php echo e(old('telefono')); ?>">
          <?php if($errors->has('telefono')): ?>
          <p><?php echo e($errors->first('telefono')); ?></p>
          <?php endif; ?>
        </div>
        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Email</label>
          <input type="text" name="correo" class="form-control" id="correo" rows="3" placeholder="email@example.com"
          value="<?php echo e(old('correo')); ?>">
          <?php if($errors->has('correo')): ?>
          <p><?php echo e($errors->first('correo')); ?></p>
          <?php endif; ?>
        </div>
      
        <div class="mb-3">
          <label for="inputPassword" class="form-label">Clave</label>
          <input type="password" name="clave" class="form-control" id="clave" rows="3" placeholder="Mayor a 6 caracteres.">
          <?php if($errors->has('clave')): ?>
            <p><?php echo e($errors->first('clave')); ?></p>
          <?php endif; ?>
        </div>    
       
        <button type="submit" class="btn btn-primary">Crear Estudiante</button>
    </form>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>