<?php $__env->startSection('title', "Ingresar Notas"); ?>
<?php $__env->startSection('content'); ?>
    <h1>Ingresar Notas</h1>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
      <h6>Por favor complete los campos requeridos:</h6>
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('nota.store')); ?>">
       
        <?php echo csrf_field(); ?>


        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Nota 1: </label>
          <input type="text" name="nota1" class="form-control" id="nota1" rows="3"
          value="<?php echo e(old('nota1')); ?>">
          
          <?php if($errors->has('nota1')): ?>
            <p><?php echo e($errors->first('nota1')); ?></p>
          <?php endif; ?>
        </div>
        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Nota 2:</label>
          <input type="text" name="nota2" class="form-control" id="nota2" rows="3" 
          value="<?php echo e(old('nota2')); ?>">
          <?php if($errors->has('nota2')): ?>
          <p><?php echo e($errors->first('nota2')); ?></p>
          <?php endif; ?>
        </div>

        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Nota 3:</label>
          <input type="text" name="nota3" class="form-control" id="nota3" rows="3" 
          value="<?php echo e(old('nota3')); ?>">
          <?php if($errors->has('nota3')): ?>
          <p><?php echo e($errors->first('nota3')); ?></p>
          <?php endif; ?>
        </div>

        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Nota 4:</label>
          <input type="text" name="nota4" class="form-control" id="nota4" rows="3" 
          value="<?php echo e(old('nota4')); ?>">
          <?php if($errors->has('nota4')): ?>
          <p><?php echo e($errors->first('nota4')); ?></p>
          <?php endif; ?>
        </div>

        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Parcial:</label>
          <input type="text" name="parcial" class="form-control" id="parcial" rows="3" 
          value="<?php echo e(old('parcial')); ?>">
          <?php if($errors->has('parcial')): ?>
          <p><?php echo e($errors->first('parcial')); ?></p>
          <?php endif; ?>
        </div>

        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Promedio:</label>
          <input type="text" name="promedio" class="form-control" id="promedio" rows="3" 
          value="<?php echo e(old('promedio')); ?>">
          <?php if($errors->has('promedio')): ?>
          <p><?php echo e($errors->first('promedio')); ?></p>
          <?php endif; ?>
        </div>

        <div class="mb-3">
          <label class="form-label">Alumno: </label>
          <select class="form-select" name="idalumno">
            <option value="">-Seleccione Alumno</option>
            <?php $__currentLoopData = $categoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorias): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($categorias['idalumno']); ?>"><?php echo e($categorias['nombre']); ?></option>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label">Profesor: </label>
          <select class="form-select" name="idprofesor">
            <option value="">-Seleccione Profesor</option>
            <?php $__currentLoopData = $categoria1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorias1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($categorias1['idprofesor']); ?>"><?php echo e($categorias1['nombre']); ?></option>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label">Curso: </label>
          <select class="form-select" name="idcurso">
            <option value="">-Seleccione Curso</option>
            <?php $__currentLoopData = $categoria2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorias2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($categorias2['idcurso']); ?>"><?php echo e($categorias2['nombrecurso']); ?></option>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

       
        <button type="submit" class="btn btn-primary">Ingresar Notas</button>
    </form>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>