<?php $__env->startSection('contenido'); ?>
    <h1>Editar Usuario</h1>
    <?php if(session()->has('info')): ?>
        <div class="alert alert-successs"><?php echo e(session('info')); ?></div>
        
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('users.update', $user->id)); ?>" method="POST">
        <?php echo method_field('PUT'); ?>

        <?php echo csrf_field(); ?>

    
        <p><label for="nombre">
            Nombre
            <input type="text" name="name" value="<?php echo e($user->name); ?>">
            <?php echo $errors->first('name', '<span class=error>:user</span>'); ?>

        </label></p>

        <p><label for="email">
            Email
            <input type="text" name="email" value="<?php echo e($user->email); ?>">
            <?php echo $errors->first('email', '<span class=error>:user</span>'); ?>

        </label></p>

        <p><label for="role">
            Rol
            <input type="text" name="rol" value="<?php echo e($user->role); ?>">
            <?php echo $errors->first('role', '<span class=error>:user</span>'); ?>

        </label></p>

        
        <input type="submit" value="Enviar">

</form>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>