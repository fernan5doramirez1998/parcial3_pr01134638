<?php $__env->startSection('content'); ?>



<h2>Estudiante: <?php echo e($alumno->nombre); ?></h2>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th>ID</th>
            <th>NOMBRE</th>
            <th>APELLIDO</th>
            <th>NACIMIENTO</th>
            <th>DIRECCIÓN</th>
            <th>GÉNERO</th>
            <th>TELÉFONO</th>
            <th>EMAIL</th>
           
        </tr>
    </thead>
    <tbody>
        <th>
            <?php echo e($alumno->idalumno); ?>

        </th>
        <th>
            <?php echo e($alumno->nombre); ?>

        </th>
        <th>
            <?php echo e($alumno->apellido); ?>

        </th>
        <th>
            <?php echo e($alumno->fechanacimiento); ?>

        </th>
        <th>
            <?php echo e($alumno->direccion); ?>

        </th>
        <th>
            <?php echo e($alumno->genero); ?>

        </th>
        <th>
            <?php echo e($alumno->telefono); ?>

        </th>
        <th>
            <?php echo e($alumno->direccion); ?>

        </th>
       
    </tbody>
       
</table>
<div class="d-flex justify-content-between">
    <p>
       <a class="btn btn-primary" href="<?php echo e(route('alumno.index')); ?>">Regresar al listado de Estudiantes.</a>
   </p>
</div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>