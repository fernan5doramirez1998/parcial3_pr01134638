<?php $__env->startSection('title', "Crear Profesión"); ?>
<?php $__env->startSection('content'); ?>
    <h1>Crear Curso</h1>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
      <h6>Por favor complete los campos requeridos:</h6>
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('curso.store')); ?>">
       
        <?php echo csrf_field(); ?>


        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Ingrese Curso: </label>
            <input type="text" name="nombrecurso" class="form-control" id="nombrecurso" rows="3" placeholder="Ejemplo: Programación III"
            value="<?php echo e(old('nombrecurso')); ?>">
            <br>

        </div>
        <div class="mb-3">
            <label for="exampleFormControlTextarea1" class="form-label">Ingrese Año</label>
            <input type="text" name="anio" class="form-control" id="anio" rows="3" placeholder="Año: 2021"
               value="<?php echo e(old('anio')); ?>">
            <?php if($errors->has('anio')): ?>
              <p><?php echo e($errors->first('anio')); ?></p>
            <?php endif; ?>
        </div>     
            
        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Ingrese Ciclo</label>
          <input type="text" name="ciclo" class="form-control" id="ciclo" rows="3" placeholder="Ciclo: II"
             value="<?php echo e(old('ciclo')); ?>">
          <?php if($errors->has('ciclo')): ?>
            <p><?php echo e($errors->first('ciclo')); ?></p>
          <?php endif; ?>
        </div>
        
        <div class="mb-3">
          <label class="form-label">Código Profesor: </label>
          <select class="form-select" name="idprofesor">
            <option value="">-Seleccione Profesor</option>
            
          </select>
        </div>
       
        <button type="submit" class="btn btn-primary">Crear Profesor</button>
    </form>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>